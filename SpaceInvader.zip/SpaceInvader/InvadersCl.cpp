//
// Created by Vaidas  on 30/11/2016.
//

#include "InvadersCl.h"


InvadersCl::InvadersCl(){
    invader.setSize(sf::Vector2f(30, 20));
    invader.setFillColor(sf::Color::Green);
    //invader.setPosition(1, 1);

}