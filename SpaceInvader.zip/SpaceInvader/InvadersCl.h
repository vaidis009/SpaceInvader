//
// Created by Vaidas  on 30/11/2016.
//

#ifndef SPACEINVADER_INVADERSCL_H
#define SPACEINVADER_INVADERSCL_H
#include <SFML/Graphics.hpp>
#include <iostream>


class InvadersCl {
public:
    sf::RectangleShape invader;
    InvadersCl();

};


#endif //SPACEINVADER_INVADERSCL_H
