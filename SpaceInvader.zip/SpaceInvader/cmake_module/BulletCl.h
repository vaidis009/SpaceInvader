//
// Created by Vaidas  on 07/12/2016.
//

#ifndef SPACEINVADER_BULLETCL_H
#define SPACEINVADER_BULLETCL_H
#include <SFML/Graphics.hpp>
#include <iostream>

class BulletCl {
public:
    sf::RectangleShape bullet;
    BulletCl();
};


#endif //SPACEINVADER_BULLETCL_H



