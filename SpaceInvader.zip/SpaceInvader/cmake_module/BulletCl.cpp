//
// Created by Vaidas  on 07/12/2016.
//

#include "BulletCl.h"




BulletCl::BulletCl(){
    bullet.setSize(sf::Vector2f(2, 5));
    bullet.setFillColor(sf::Color::Green);
    //invader.setPosition(1, 1);

}